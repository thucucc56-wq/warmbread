class DragPhysicsEngine {
  constructor(smoothingFactor = 0.22) {
    this.smoothingFactor = smoothingFactor;
  }

  approach(currentValue, targetValue) {
    return currentValue + (targetValue - currentValue) * this.smoothingFactor;
  }

  isPointOverDropZone(clientX, clientY) {
    const elementAtPointer = document.elementFromPoint(clientX, clientY);
    return Boolean(elementAtPointer && elementAtPointer.closest('[data-drop-zone]'));
  }
}

class BakeryShowcaseApp {
  constructor() {
    this.physics = new DragPhysicsEngine();
    
    this.state = {
      activePointerId: null,
      activeProductCard: null,
      activeCloneElement: null,
      dragOriginLeft: 0,
      dragOriginTop: 0,
      cloneWidth: 0,
      cloneHeight: 0,
      pointerOffsetX: 0,
      pointerOffsetY: 0,
      currentLeft: 0,
      currentTop: 0,
      targetLeft: 0,
      targetTop: 0,
      isDragging: false,
      isAnimationFramePending: false,
      isOverDropZone: false,
      lastFocusedElement: null,
      releaseTimeoutId: 0
    };

    this.cartState = {
      items: [],
      deliveryPrice: 200,
      isDeliveryChecked: false,
      currentViewedProduct: null
    };

    this.dom = {
      productGrid: null,
      dropZone: null,
      dropZoneStatus: null,
      dialog: null,
      dialogCloseBtn: null,
      dialogImage: null,
      dialogCategory: null,
      dialogTitle: null,
      dialogDescription: null,
      dialogPrice: null,
      dialogServing: null,
      dialogIngredients: null,
      addToCartBtn: null,
      
      cartOpenBtn: null,
      cartCountLabels: [],
      cartDialog: null,
      cartCloseBtn: null,
      cartList: null,
      cartDeliveryCheckbox: null,
      cartTotalLabel: null,
      cartSubmitBtn: null,

      orderOpenBtn: null,
      orderDialog: null,
      orderCloseBtn: null
    };

    this.placeholderDialogImage = 'https://placehold.co/800x800/FAF6F0/8B5A2B?text=%D0%A4%D0%BE%D1%82%D0%BE+%D0%B8%D0%B7%D0%B4%D0%B5%D0%BB%D0%B8%D1%8F';
  }

  initialize() {
    this.cacheDomReferences();
    this.bindStaticEvents();
    this.bindProductCardEvents();
    this.bindDialogEvents();
    this.bindCartEvents();
    this.bindOrderEvents();
    this.updateDropZoneStatus('Площадка готова к взаимодействию.');
    this.renderCartUI();
  }

  cacheDomReferences() {
    this.dom.productGrid = document.querySelector('.product-grid');
    this.dom.dropZone = document.querySelector('[data-drop-zone]');
    this.dom.dropZoneStatus = document.querySelector('[data-drop-zone-status]');
    
    this.dom.dialog = document.querySelector('[data-product-dialog]');
    this.dom.dialogCloseBtn = document.querySelector('[data-dialog-close]');
    this.dom.dialogImage = document.querySelector('[data-dialog-image]');
    this.dom.dialogCategory = document.querySelector('[data-dialog-category]');
    this.dom.dialogTitle = document.querySelector('[data-dialog-title]');
    this.dom.dialogDescription = document.querySelector('[data-dialog-description]');
    this.dom.dialogPrice = document.querySelector('[data-dialog-price]');
    this.dom.dialogServing = document.querySelector('[data-dialog-serving]');
    this.dom.dialogIngredients = document.querySelector('[data-dialog-ingredients]');
    this.dom.addToCartBtn = document.querySelector('[data-add-to-cart]');
    
    this.dom.cartOpenBtn = document.querySelector('[data-cart-open]');
    this.dom.cartCountLabels = Array.from(document.querySelectorAll('[data-cart-count]'));
    this.dom.cartDialog = document.querySelector('[data-cart-dialog]');
    this.dom.cartCloseBtn = document.querySelector('[data-cart-close]');
    this.dom.cartList = document.querySelector('[data-cart-list]');
    this.dom.cartDeliveryCheckbox = document.querySelector('[data-cart-delivery]');
    this.dom.cartTotalLabel = document.querySelector('[data-cart-total]');
    this.dom.cartSubmitBtn = document.querySelector('[data-cart-submit]');

    this.dom.orderOpenBtn = document.querySelector('[data-order-open]');
    this.dom.orderDialog = document.querySelector('[data-order-dialog]');
    this.dom.orderCloseBtn = document.querySelector('[data-order-close]');
  }

  bindStaticEvents() {
    document.addEventListener('pointermove', this.handleGlobalPointerMove);
    document.addEventListener('pointerup', this.handleGlobalPointerUp);
    document.addEventListener('pointercancel', this.handleGlobalPointerCancel);
    window.addEventListener('resize', this.handleViewportMutation);
    window.addEventListener('scroll', this.handleViewportMutation, { passive: true });
  }

  bindProductCardEvents() {
    if (!this.dom.productGrid) return;
    this.dom.productGrid.addEventListener('pointerdown', this.handleProductPointerDown);
  }

  bindDialogEvents() {
    if (this.dom.dialog) {
      this.dom.dialog.addEventListener('close', this.handleDialogClose);
      this.dom.dialog.addEventListener('click', this.handleDialogBackdropClick);
    }
    if (this.dom.dialogCloseBtn) {
      this.dom.dialogCloseBtn.addEventListener('click', () => {
        this.dom.dialog.close();
      });
    }
  }

  bindCartEvents() {
    if (this.dom.addToCartBtn) {
      this.dom.addToCartBtn.addEventListener('click', () => this.addItemToCart());
    }
    if (this.dom.cartOpenBtn) {
      this.dom.cartOpenBtn.addEventListener('click', () => this.dom.cartDialog.showModal());
    }
    if (this.dom.cartCloseBtn) {
      this.dom.cartCloseBtn.addEventListener('click', () => this.dom.cartDialog.close());
    }
    if (this.dom.cartDialog) {
      this.dom.cartDialog.addEventListener('click', (e) => {
        if (e.target === this.dom.cartDialog) this.dom.cartDialog.close();
      });
    }
    if (this.dom.cartDeliveryCheckbox) {
      this.dom.cartDeliveryCheckbox.addEventListener('change', (e) => {
        this.cartState.isDeliveryChecked = e.target.checked;
        this.renderCartUI();
      });
    }
    if (this.dom.cartSubmitBtn) {
      this.dom.cartSubmitBtn.addEventListener('click', () => {
        if (this.cartState.items.length === 0) {
          alert('Корзина пуста');
          return;
        }
        alert('Ваш заказ успешно оформлен! Спасибо.');
        this.cartState.items = [];
        this.cartState.isDeliveryChecked = false;
        this.dom.cartDeliveryCheckbox.checked = false;
        this.renderCartUI();
        this.dom.cartDialog.close();
      });
    }
    if (this.dom.cartList) {
      this.dom.cartList.addEventListener('click', (e) => {
        const removeBtn = e.target.closest('[data-remove-index]');
        if (removeBtn) {
          const idx = parseInt(removeBtn.getAttribute('data-remove-index'), 10);
          this.cartState.items.splice(idx, 1);
          this.renderCartUI();
        }
      });
    }
  }

  bindOrderEvents() {
    if (this.dom.orderOpenBtn && this.dom.orderDialog) {
      this.dom.orderOpenBtn.addEventListener('click', () => {
        this.dom.orderDialog.showModal();
      });
    }
    if (this.dom.orderCloseBtn) {
      this.dom.orderCloseBtn.addEventListener('click', () => {
        this.dom.orderDialog.close();
      });
    }
    if (this.dom.orderDialog) {
      this.dom.orderDialog.addEventListener('click', (e) => {
        if (e.target === this.dom.orderDialog) this.dom.orderDialog.close();
      });
    }
  }

  handleProductPointerDown = (event) => {
    const productCard = event.target.closest('[data-product-card]');
    if (!productCard || !this.dom.productGrid.contains(productCard)) return;
    if (event.button !== 0) return;

    if (this.state.activeProductCard) this.resetDragSession();
    
    event.preventDefault();

    this.state.activePointerId = event.pointerId;
    this.state.activeProductCard = productCard;
    this.state.lastFocusedElement = productCard;
    this.state.isDragging = false;
    this.state.isOverDropZone = false;

    productCard.classList.add('is-grabbed');
    productCard.style.touchAction = 'none';

    const productCardRect = productCard.getBoundingClientRect();

    this.state.dragOriginLeft = productCardRect.left;
    this.state.dragOriginTop = productCardRect.top;
    this.state.cloneWidth = productCardRect.width;
    this.state.cloneHeight = productCardRect.height;
    this.state.pointerOffsetX = event.clientX - productCardRect.left;
    this.state.pointerOffsetY = event.clientY - productCardRect.top;
    this.state.currentLeft = productCardRect.left;
    this.state.currentTop = productCardRect.top;
    this.state.targetLeft = productCardRect.left;
    this.state.targetTop = productCardRect.top;

    this.createDragClone(productCard, productCardRect);

    try {
      productCard.setPointerCapture(event.pointerId);
    } catch {}

    this.updateDropZoneStatus('Карточка захвачена. Тащите её в зону.');
    this.scheduleAnimationFrame();
  };

  handleGlobalPointerMove = (event) => {
    if (event.pointerId !== this.state.activePointerId || !this.state.activeCloneElement) return;

    this.state.targetLeft = event.clientX - this.state.pointerOffsetX;
    this.state.targetTop = event.clientY - this.state.pointerOffsetY;

    const movementDistance = Math.hypot(
      event.clientX - (this.state.dragOriginLeft + this.state.pointerOffsetX),
      event.clientY - (this.state.dragOriginTop + this.state.pointerOffsetY)
    );

    if (!this.state.isDragging && movementDistance > 6) {
      this.state.isDragging = true;
      this.updateDropZoneStatus('Наведите изделие на выделенную зону.');
    }

    this.scheduleAnimationFrame();
  };

  handleGlobalPointerUp = (event) => {
    if (event.pointerId !== this.state.activePointerId) return;
    const shouldOpenDialog = this.state.isDragging && this.state.isOverDropZone;
    this.finalizeDragSession(shouldOpenDialog);
  };

  handleGlobalPointerCancel = (event) => {
    if (event.pointerId !== this.state.activePointerId) return;
    this.finalizeDragSession(false);
  };

  handleViewportMutation = () => {
    if (this.state.activeProductCard) {
      this.finalizeDragSession(false);
    }
  };

  createDragClone(productCard, productCardRect) {
    const dragCloneElement = productCard.cloneNode(true);
    dragCloneElement.classList.add('product-card', 'is-clone');
    dragCloneElement.style.left = `${productCardRect.left}px`;
    dragCloneElement.style.top = `${productCardRect.top}px`;
    dragCloneElement.style.width = `${productCardRect.width}px`;
    dragCloneElement.style.height = `${productCardRect.height}px`;
    dragCloneElement.style.opacity = '1';
    dragCloneElement.style.transform = 'translate3d(0, 0, 0)';

    document.body.append(dragCloneElement);
    this.state.activeCloneElement = dragCloneElement;
  }

  scheduleAnimationFrame() {
    if (this.state.isAnimationFramePending) return;
    this.state.isAnimationFramePending = true;
    requestAnimationFrame(this.renderDragFrame);
  }

  renderDragFrame = () => {
    this.state.isAnimationFramePending = false;
    if (!this.state.activeCloneElement) return;

    this.state.currentLeft = this.physics.approach(this.state.currentLeft, this.state.targetLeft);
    this.state.currentTop = this.physics.approach(this.state.currentTop, this.state.targetTop);

    const translateX = this.state.currentLeft - this.state.dragOriginLeft;
    const translateY = this.state.currentTop - this.state.dragOriginTop;

    this.state.activeCloneElement.style.transform = `translate3d(${translateX}px, ${translateY}px, 0)`;

    const centerX = this.state.currentLeft + this.state.cloneWidth / 2;
    const centerY = this.state.currentTop + this.state.cloneHeight / 2;
    const isOverDropZone = this.physics.isPointOverDropZone(centerX, centerY);

    this.setDropZoneVisualState(isOverDropZone);

    if (
      Math.abs(this.state.currentLeft - this.state.targetLeft) > 0.4 ||
      Math.abs(this.state.currentTop - this.state.targetTop) > 0.4
    ) {
      this.scheduleAnimationFrame();
    }
  };

  setDropZoneVisualState(isActive) {
    if (!this.dom.dropZone) return;
    if (isActive === this.state.isOverDropZone) return;
    
    this.state.isOverDropZone = isActive;
    this.dom.dropZone.classList.toggle('is-dragover', isActive);

    if (isActive) {
      this.updateDropZoneStatus('Отлично. Отпустите изделие здесь.');
    } else {
      this.updateDropZoneStatus('Изделие покинуло зону раскрытия.');
    }
  }

  updateDropZoneStatus(message) {
    if (this.dom.dropZoneStatus) {
      this.dom.dropZoneStatus.textContent = message;
    }
  }

  finalizeDragSession(shouldOpenDialog) {
    if (!this.state.activeProductCard) return;

    const activeProductCard = this.state.activeProductCard;
    const activeCloneElement = this.state.activeCloneElement;

    activeProductCard.classList.remove('is-grabbed');
    activeProductCard.style.touchAction = '';

    if (this.dom.dropZone) this.dom.dropZone.classList.remove('is-dragover');

    this.updateDropZoneStatus(shouldOpenDialog ? 'Открываю состав...' : 'Площадка готова к взаимодействию.');

    if (activeCloneElement) {
      activeCloneElement.style.opacity = '0';
      window.clearTimeout(this.state.releaseTimeoutId);
      this.state.releaseTimeoutId = window.setTimeout(() => {
        activeCloneElement.remove();
        if (shouldOpenDialog) this.openProductDialog(activeProductCard);
      }, 140);
    } else if (shouldOpenDialog) {
      this.openProductDialog(activeProductCard);
    }

    this.state.activePointerId = null;
    this.state.activeProductCard = null;
    this.state.activeCloneElement = null;
    this.state.isDragging = false;
    this.state.isOverDropZone = false;
  }

  resetDragSession() {
    if (this.state.activeCloneElement) this.state.activeCloneElement.remove();
    if (this.state.activeProductCard) {
      this.state.activeProductCard.classList.remove('is-grabbed');
      this.state.activeProductCard.style.touchAction = '';
    }
    if (this.dom.dropZone) this.dom.dropZone.classList.remove('is-dragover');
    
    window.clearTimeout(this.state.releaseTimeoutId);
    this.state.activePointerId = null;
    this.state.activeProductCard = null;
    this.state.activeCloneElement = null;
    this.state.isDragging = false;
    this.state.isOverDropZone = false;
  }

  openProductDialog(productCard) {
    if (!this.dom.dialog) return;
    const productData = this.readProductData(productCard);
    this.cartState.currentViewedProduct = productData;
    this.populateDialog(productData);
    this.state.lastFocusedElement = productCard;
    if (!this.dom.dialog.open) {
      this.dom.dialog.showModal();
    }
  }

  readProductData(productCard) {
    const {
      productId = 'unknown',
      productName = 'Без названия',
      productCategory = 'Каталог',
      price = '0',
      serving = '—',
      image = this.placeholderDialogImage,
      imageAlt = '',
      ingredients = '',
      description = ''
    } = productCard.dataset;

    return {
      productId,
      productName,
      productCategory,
      price: Number(price) || 0,
      serving,
      image,
      imageAlt: imageAlt || productName,
      ingredients: ingredients.split('|').map(i => i.trim()).filter(Boolean),
      description
    };
  }

  populateDialog(productData) {
    if (this.dom.dialogCategory) this.dom.dialogCategory.textContent = productData.productCategory;
    if (this.dom.dialogTitle) this.dom.dialogTitle.textContent = productData.productName;
    if (this.dom.dialogDescription) this.dom.dialogDescription.textContent = productData.description;
    if (this.dom.dialogPrice) {
      this.dom.dialogPrice.textContent = new Intl.NumberFormat('ru-RU', {
        style: 'currency', currency: 'RUB', maximumFractionDigits: 0
      }).format(productData.price);
    }
    if (this.dom.dialogServing) this.dom.dialogServing.textContent = productData.serving;
    if (this.dom.dialogIngredients) {
      this.dom.dialogIngredients.innerHTML = productData.ingredients
        .map(i => `<li>${this.escapeHTML(i)}</li>`).join('');
    }
    if (this.dom.dialogImage) {
      this.dom.dialogImage.onerror = null;
      this.dom.dialogImage.src = productData.image || this.placeholderDialogImage;
      this.dom.dialogImage.alt = productData.imageAlt;
      this.dom.dialogImage.onerror = () => {
        this.dom.dialogImage.onerror = null;
        this.dom.dialogImage.src = this.placeholderDialogImage;
      };
    }
  }

  escapeHTML(value) {
    return value
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#39;');
  }

  handleDialogClose = () => {
    if (this.state.lastFocusedElement && typeof this.state.lastFocusedElement.focus === 'function') {
      this.state.lastFocusedElement.focus({ preventScroll: true });
    }
    this.cartState.currentViewedProduct = null;
  };

  handleDialogBackdropClick = (event) => {
    if (event.target === this.dom.dialog) {
      this.dom.dialog.close();
    }
  };

  addItemToCart() {
    if (this.cartState.currentViewedProduct) {
      this.cartState.items.push(this.cartState.currentViewedProduct);
      this.renderCartUI();
      const btnText = this.dom.addToCartBtn.textContent;
      this.dom.addToCartBtn.textContent = 'Добавлено!';
      setTimeout(() => {
        this.dom.addToCartBtn.textContent = btnText;
      }, 1000);
    }
  }

  renderCartUI() {
    const itemCount = this.cartState.items.length;
    this.dom.cartCountLabels.forEach(lbl => lbl.textContent = itemCount);
    
    if (this.dom.cartList) {
      if (itemCount === 0) {
        this.dom.cartList.innerHTML = '<li><span style="color: var(--color-muted);">Корзина пуста</span></li>';
      } else {
        this.dom.cartList.innerHTML = this.cartState.items.map((item, idx) => `
          <li>
            <strong style="color: var(--color-text);">${this.escapeHTML(item.productName)}</strong>
            <span style="font-weight: 700; color: var(--color-accent-strong);">${item.price} ₽</span>
            <button type="button" data-remove-index="${idx}">×</button>
          </li>
        `).join('');
      }
    }

    if (this.dom.cartTotalLabel) {
      let total = this.cartState.items.reduce((sum, item) => sum + item.price, 0);
      if (this.cartState.isDeliveryChecked && itemCount > 0) {
        total += this.cartState.deliveryPrice;
      }
      this.dom.cartTotalLabel.textContent = new Intl.NumberFormat('ru-RU', {
        style: 'currency', currency: 'RUB', maximumFractionDigits: 0
      }).format(total);
    }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const BakeryShowcaseAppInstance = new BakeryShowcaseApp();
  BakeryShowcaseAppInstance.initialize();
});